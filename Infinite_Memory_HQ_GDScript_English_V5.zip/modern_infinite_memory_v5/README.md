# Infinite Memory - High Quality (GDScript)

This ZIP contains only the **Infinite Memory** minigame as a Godot 4 / GDScript project.

## Included
- a polished **infinite memory game**
- **focus system** (mistakes and slow decisions reduce focus)
- **difficulty increases by +10% every 5 minutes**
- **no save states during a run**
- **test-user leaderboard** for UI demo purposes
- **host placeholder scene** so the game can be tested before the real main menu exists

## Important scenes
- `res://main.tscn` = temporary host placeholder
- `res://scenes/MemoryGame.tscn` = the actual minigame that should later be embedded into the real menu

## Integration
The real main menu can later instantiate `res://scenes/MemoryGame.tscn` directly.
The minigame emits `request_exit_to_host(final_score, matches, best_combo)` when the host should take over again.

## V5 gameplay
Each wave contains 5 pairs / 10 cards. Matched pairs disappear. When the board is empty and Focus is still above 0%, the next wave is generated automatically.
