extends Control

const MEMORY_SCENE := preload("res://minigames/memory/scenes/MemoryGame.tscn")
var memory_instance

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_build_placeholder()

func _build_placeholder() -> void:
	var bg := ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color.from_string("#07111d", Color.BLACK)
	add_child(bg)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(720, 380)
	panel.add_theme_stylebox_override("panel", _panel_style("#0c1828", "#3f6c97", 26, 0.98))
	center.add_child(panel)

	var margin := MarginContainer.new()
	_set_margins(margin, 30, 30, 30, 30)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 16)
	margin.add_child(box)

	var title := Label.new()
	title.text = "HOST PLACEHOLDER"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 34)
	title.add_theme_color_override("font_color", Color.from_string("#f2f7ff", Color.WHITE))
	box.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "The real main menu will be created by another team member.\nThis placeholder only exists so the Infinite Memory minigame can be tested now."
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle.add_theme_font_size_override("font_size", 17)
	subtitle.add_theme_color_override("font_color", Color.from_string("#a8bfd7", Color.WHITE))
	box.add_child(subtitle)

	var info := Label.new()
	info.text = "Final integration target: res://scenes/MemoryGame.tscn"
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.add_theme_font_size_override("font_size", 14)
	info.add_theme_color_override("font_color", Color.from_string("#7ea6d1", Color.WHITE))
	box.add_child(info)

	var open_button := Button.new()
	open_button.text = "START INFINITE MEMORY"
	open_button.custom_minimum_size = Vector2(290, 56)
	_apply_button_theme(open_button, true)
	open_button.pressed.connect(_open_memory_game)
	box.add_child(open_button)

func _open_memory_game() -> void:
	if memory_instance != null:
		return
	memory_instance = MEMORY_SCENE.instantiate()
	add_child(memory_instance)
	if memory_instance.has_signal("request_exit_to_host"):
		memory_instance.request_exit_to_host.connect(_on_request_exit_to_host)
	get_child(1).visible = false

func _on_request_exit_to_host(_score: int, _matches: int, _best_combo: int) -> void:
	if memory_instance != null:
		memory_instance.queue_free()
		memory_instance = null
	get_child(1).visible = true

func _apply_button_theme(button: BaseButton, primary: bool) -> void:
	var normal := _button_style("#2d6bff" if primary else "#132236", "#77b1ff")
	var hover := _button_style("#3a7dff" if primary else "#1c2f4a", "#9cc8ff")
	var pressed := _button_style("#2455cb" if primary else "#102030", "#5f9ef7")
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("focus", hover)
	button.add_theme_stylebox_override("disabled", normal)
	button.add_theme_color_override("font_color", Color.WHITE)
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color.WHITE)
	button.add_theme_font_size_override("font_size", 17)

func _button_style(bg_hex: String, border_hex: String) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color.from_string(bg_hex, Color.DARK_BLUE)
	style.border_color = Color.from_string(border_hex, Color.WHITE)
	style.set_border_width_all(1)
	style.set_corner_radius_all(16)
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.35)
	style.shadow_size = 10
	style.shadow_offset = Vector2(0, 5)
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	return style

func _panel_style(bg_hex: String, border_hex: String, radius: int, alpha: float) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	var c := Color.from_string(bg_hex, Color.DARK_BLUE)
	c.a = alpha
	style.bg_color = c
	style.border_color = Color.from_string(border_hex, Color.WHITE)
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.38)
	style.shadow_size = 18
	style.shadow_offset = Vector2(0, 8)
	return style

func _set_margins(container: MarginContainer, left: int, top: int, right: int, bottom: int) -> void:
	container.add_theme_constant_override("margin_left", left)
	container.add_theme_constant_override("margin_top", top)
	container.add_theme_constant_override("margin_right", right)
	container.add_theme_constant_override("margin_bottom", bottom)
